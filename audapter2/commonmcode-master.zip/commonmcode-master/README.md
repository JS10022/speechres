# commonmcode
MATLAB functions used in various projects.

Author: Shanqing Cai (shanqing.cai@gmail.com)


