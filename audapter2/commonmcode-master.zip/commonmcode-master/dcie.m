dbclear if error;
