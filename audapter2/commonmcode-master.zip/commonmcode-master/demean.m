function y=demean(x)
y=x-nanmean(x);
return