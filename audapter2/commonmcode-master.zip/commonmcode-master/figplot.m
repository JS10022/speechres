function figplot(varargin)
    figure;
    plot(varargin{1:nargin});

    hold on;    
    
return