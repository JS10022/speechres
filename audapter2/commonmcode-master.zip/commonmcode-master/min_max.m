function r = min_max(x)
r(1) = min(x);
r(2) = max(x);
return
