function my_subplot
    subplot('Position',[0.025,0.025,0.925,0.925]);
return