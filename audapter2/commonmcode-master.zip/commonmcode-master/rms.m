% Author: Shanqing Cai (shanqing.cai@gmail.com)
% Date: 2008-09-16

function r=rms(x)
    r=sqrt(mean(x.^2));
return
