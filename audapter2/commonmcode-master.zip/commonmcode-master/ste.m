% ste: Standard error
% 
% Author: Shanqing Cai (shanqing.cai@gmail.com)
% Date: 2009-01-24

function se=ste(x)
    se=std(x)/sqrt(length(x));
return
