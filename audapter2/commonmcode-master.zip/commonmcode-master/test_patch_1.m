figure
plot([0,1],[0,1],'k');
hold on;
patch([0,0,1,1],[0,1,1,0],'r','FaceAlpha',0.5);