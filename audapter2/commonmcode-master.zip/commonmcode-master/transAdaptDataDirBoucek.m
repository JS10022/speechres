function d = transAdaptDataDirBoucek(varargin)
    d = 'G:\CS_2004\ALL_DATA\';
return