% upper1: Convert the first character in a string to upper case
%
% Author: Shanqing Cai (shanqing.cai@gmail.com)
% Date: 2009-01-30

function str1=upper1(str0)
    str1=str0;
    str1(1)=upper(str1(1));
return
