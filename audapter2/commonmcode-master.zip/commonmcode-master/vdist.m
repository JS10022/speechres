function d=vdist(v1,v2)
d=norm(v1-v2);
return